import { Checkbox } from "antd";
import "../../assets/css/common/common.scss"

const CustomCheckbox = () => {
  return <Checkbox />;
};

export default CustomCheckbox;
