//export const BASE_URL = "https://54jr98p7-8900.inc1.devtunnels.ms/api";
// export const BASE_URL = "http://16.171.111.244/api";
// export const BASE_URL = "http://16.170.217.59/api";
// export const BASE_URL = "https://api.wepickapp.com/api";
export const BASE_URL = "YOUR_NEW_BACKEND_API_URL";

// export const BASE_URL = "http://51.21.116.59/api";
// export const BASE_URL = "https://api.testing.winwithwits.com/api";
  