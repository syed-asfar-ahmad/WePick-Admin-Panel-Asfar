import React from "react";

const NoDataFound = () => {
  return <p className="m-0">No data found</p>;
};

export default NoDataFound;
